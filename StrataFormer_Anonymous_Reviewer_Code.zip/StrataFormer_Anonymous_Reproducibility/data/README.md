# LMVD data interface

The package consumes processed LMVD feature sequences and does not redistribute source videos or personal metadata. Obtain the dataset under the provider's terms, then map each sample to a stable participant identifier, binary label, VGGish array, and visual structured-feature array.

## Required tensors

- Audio: NumPy `float32`, shape `[T_audio, 128]`, representing the released VGGish embedding sequence.
- Visual: NumPy `float32`, shape `[T_visual, 171]`, representing the concatenated FAU, landmark, gaze, and head-pose descriptors used in the manuscript.
- Label: `0` for non-depressed and `1` for depressed.
- Participant ID: split metadata only; it is never returned as a numerical model feature.

## Preprocessing order

1. When reliable step durations are available, crop both modalities to their common leading source-video interval.
2. Replace non-finite feature values with zero.
3. Truncate or right-pad audio to 186 steps and visual to 915 steps.
4. Fit channel-wise means and standard deviations on the eight training folds only.
5. Normalize validation and test data with those training-fold statistics.
6. Restore padded positions to zero and propagate Boolean masks through every temporal and attention block.

If the downloaded features have already been aligned to a common source interval, set `features_already_common_interval: true`. Do not invent step durations. Run `scripts/audit_data.py` to verify shapes, label counts, and padding/truncation outcomes before training.

## Privacy-safe repository upload

Do not commit raw videos, names, platform handles, private paths, or unhashed identifiers. An anonymous repository may contain a manifest template and aggregate fold counts. If exact fold assignments are shared, use dataset-provided anonymous sample/participant keys and confirm that their license permits redistribution.
