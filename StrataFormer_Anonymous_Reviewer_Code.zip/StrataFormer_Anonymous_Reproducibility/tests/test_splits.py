from __future__ import annotations

import unittest

import pandas as pd

from strataformer.splits import assert_participant_disjoint, make_grouped_folds, outer_split_folds


class SplitTests(unittest.TestCase):
    def setUp(self) -> None:
        rows = []
        for participant in range(20):
            for sample in range(2):
                rows.append(
                    {
                        "sample_id": f"s{participant:02d}_{sample}",
                        "participant_id": f"p{participant:02d}",
                        "label": participant % 2,
                        "audio_path": "unused.npy",
                        "visual_path": "unused.npy",
                    }
                )
        self.manifest = pd.DataFrame(rows)

    def test_assignment_is_deterministic_and_grouped(self) -> None:
        first = make_grouped_folds(self.manifest, num_folds=5, seed=2026)
        second = make_grouped_folds(self.manifest, num_folds=5, seed=2026)
        pd.testing.assert_frame_equal(first, second)
        shuffled = self.manifest.sample(frac=1.0, random_state=9).reset_index(drop=True)
        third = make_grouped_folds(shuffled, num_folds=5, seed=2026)
        pd.testing.assert_frame_equal(first, third)
        assert_participant_disjoint(first)
        self.assertEqual(set(first.fold), {1, 2, 3, 4, 5})

    def test_cyclic_validation_fold(self) -> None:
        training, validation, test = outer_split_folds(10, num_folds=10)
        self.assertEqual(validation, 1)
        self.assertEqual(test, 10)
        self.assertEqual(len(training), 8)
        self.assertNotIn(1, training)
        self.assertNotIn(10, training)


if __name__ == "__main__":
    unittest.main()
