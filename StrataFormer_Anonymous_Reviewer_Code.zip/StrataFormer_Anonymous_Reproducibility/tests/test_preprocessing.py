from __future__ import annotations

import unittest

import numpy as np

from strataformer.data import standardize_length


class PreprocessingTests(unittest.TestCase):
    def test_right_padding_and_mask(self) -> None:
        source = np.ones((3, 2), dtype=np.float32)
        output, mask = standardize_length(source, 5)
        self.assertEqual(output.shape, (5, 2))
        np.testing.assert_array_equal(mask, [True, True, True, False, False])
        np.testing.assert_array_equal(output[3:], 0.0)

    def test_truncation(self) -> None:
        source = np.arange(12, dtype=np.float32).reshape(6, 2)
        output, mask = standardize_length(source, 4)
        np.testing.assert_array_equal(output, source[:4])
        self.assertTrue(mask.all())


if __name__ == "__main__":
    unittest.main()
