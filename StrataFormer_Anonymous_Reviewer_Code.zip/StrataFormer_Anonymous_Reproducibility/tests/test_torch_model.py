from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path


TORCH_AVAILABLE = importlib.util.find_spec("torch") is not None


@unittest.skipUnless(TORCH_AVAILABLE, "PyTorch is not installed")
class TorchModelTests(unittest.TestCase):
    def setUp(self) -> None:
        import torch

        from strataformer.config import load_config

        self.torch = torch
        root = Path(__file__).resolve().parents[1]
        self.config = load_config(root / "configs/smoke.yaml")

    def test_all_variant_shapes_and_parameter_order(self) -> None:
        from strataformer.models import build_model

        torch = self.torch
        audio = torch.randn(2, 24, 128)
        visual = torch.randn(2, 64, 171)
        audio_mask = torch.ones(2, 24, dtype=torch.bool)
        visual_mask = torch.ones(2, 64, dtype=torch.bool)
        counts = {}
        for variant in ("global", "local", "serial", "full"):
            model = build_model(self.config, variant).eval()
            result = model(audio, visual, audio_mask, visual_mask)
            self.assertEqual(tuple(result["logits"].shape), (2, 2))
            counts[variant] = sum(parameter.numel() for parameter in model.parameters())
        self.assertEqual(counts["global"], counts["local"])
        self.assertGreater(counts["serial"], counts["global"])
        self.assertGreater(counts["full"], counts["serial"])

    def test_padded_values_do_not_change_output(self) -> None:
        from strataformer.models import build_model

        torch = self.torch
        torch.manual_seed(1)
        model = build_model(self.config, "full").eval()
        audio = torch.randn(1, 24, 128)
        visual = torch.randn(1, 64, 171)
        audio_mask = torch.zeros(1, 24, dtype=torch.bool)
        visual_mask = torch.zeros(1, 64, dtype=torch.bool)
        audio_mask[:, :13] = True
        visual_mask[:, :41] = True
        changed_audio = audio.clone()
        changed_visual = visual.clone()
        changed_audio[:, 13:] = torch.randn_like(changed_audio[:, 13:]) * 1000
        changed_visual[:, 41:] = torch.randn_like(changed_visual[:, 41:]) * 1000
        with torch.inference_mode():
            first = model(audio, visual, audio_mask, visual_mask)["logits"]
            second = model(changed_audio, changed_visual, audio_mask, visual_mask)["logits"]
        torch.testing.assert_close(first, second, atol=1e-6, rtol=1e-6)

    def test_mask_aware_pooling(self) -> None:
        from strataformer.models.masking import masked_average_pool

        torch = self.torch
        sequence = torch.arange(1, 9, dtype=torch.float32).view(1, 8, 1)
        mask = torch.tensor([[True, True, True, True, True, False, False, False]])
        pooled, pooled_mask = masked_average_pool(sequence, mask, 4)
        torch.testing.assert_close(pooled.flatten(), torch.tensor([2.5, 5.0]))
        self.assertTrue(pooled_mask.all())


if __name__ == "__main__":
    unittest.main()
