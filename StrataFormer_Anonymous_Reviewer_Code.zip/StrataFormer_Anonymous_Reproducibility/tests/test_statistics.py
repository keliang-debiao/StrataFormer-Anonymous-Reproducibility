from __future__ import annotations

import unittest

import numpy as np

from strataformer.statistics import paired_fold_analysis


class StatisticTests(unittest.TestCase):
    def test_reported_full_vs_global_test(self) -> None:
        full = np.array([74.86, 79.13, 77.05, 75.82, 80.11, 78.02, 73.95, 77.69, 79.21, 78.06])
        global_only = np.array([74.58, 79.33, 76.84, 75.94, 79.97, 77.77, 74.12, 77.67, 79.06, 78.12])
        result = paired_fold_analysis(full, global_only)
        self.assertAlmostEqual(result["mean_difference"], 0.05, places=8)
        self.assertAlmostEqual(result["paired_t"], 0.882, places=3)
        self.assertAlmostEqual(result["paired_p"], 0.401, places=3)
        self.assertAlmostEqual(result["cohens_dz"], 0.28, places=2)


if __name__ == "__main__":
    unittest.main()
