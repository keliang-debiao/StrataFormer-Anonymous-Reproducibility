from __future__ import annotations

import unittest
from pathlib import Path

from strataformer.architecture import analytical_parameter_counts, sequence_contract
from strataformer.config import load_config


class ArchitectureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        root = Path(__file__).resolve().parents[1]
        cls.config = load_config(root / "configs/paper.yaml")

    def test_sequence_lengths_and_pairs(self) -> None:
        contract = sequence_contract(self.config)
        self.assertEqual(contract["visual_local_chronological_positions"], 114)
        self.assertEqual(contract["visual_local_queries_with_cls"], 115)
        self.assertEqual(contract["audio_global_positions"], 31)
        self.assertEqual(contract["visual_global_queries_with_cls"], 29)
        self.assertEqual(contract["local_attention_pairs"], 21390)
        self.assertEqual(contract["global_attention_pairs"], 899)
        self.assertEqual(contract["full_attention_pairs"], 22289)
        self.assertAlmostEqual(contract["full_increase_over_local_percent"], 4.20, places=2)

    def test_parameter_counts_round_to_reported_values(self) -> None:
        counts = analytical_parameter_counts(self.config)
        rounded = {key: round(value / 1e6, 2) for key, value in counts.items()}
        self.assertEqual(rounded, {"global": 4.83, "local": 4.83, "serial": 5.09, "full": 5.16})


if __name__ == "__main__":
    unittest.main()
