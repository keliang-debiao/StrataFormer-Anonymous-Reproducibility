# Anonymous release checklist

- [ ] Replace the missing `folds/fold_assignments.csv` with the author-verified, license-compliant sample assignment.
- [ ] Verify the generated fold composition against `folds/reported_fold_composition.csv`.
- [ ] Confirm feature channel order and whether common-interval cropping has already been applied.
- [ ] Replace reference-only implementation choices with original values when original source is available.
- [ ] Run `bash run_smoke_test.sh` in the pinned environment.
- [ ] Run `python scripts/verify_repository.py` and retain a clean report.
- [ ] Confirm that `logs/reference/` remains labeled as reference material rather than raw training transcripts.
- [ ] Remove raw data, checkpoints, credentials, local absolute paths, author names, affiliations, acknowledgments, and private URLs.
- [ ] Create the anonymous hosting account and inspect commit authors as well as repository files.
- [ ] Add the anonymous repository URL to the rebuttal/manuscript only after checking that it cannot reveal identity.
- [ ] Archive the final code release and record its SHA-256 checksum in the response letter.
