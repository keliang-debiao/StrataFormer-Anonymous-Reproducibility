# Configuration provenance

This file separates manuscript-specified settings from executable defaults needed to instantiate a complete implementation.

## Explicitly specified in the manuscript

- Audio feature width 128 and visual feature width 171.
- Fixed sequence lengths 186 (audio) and 915 (visual).
- Shared embedding width 256.
- Three visual Conv1D-BatchNorm-ReLU-MaxPool blocks, convolution kernel 3/padding 1, pooling kernel 2/stride 2.
- Four residual TCN blocks with dilations 2, 4, 8, and 16.
- Local sequences of 186 audio positions and 114 visual positions.
- Global mask-aware pooling with audio kernel/stride 6 and visual kernel/stride 4, producing 31 and 28 chronological positions.
- Separate local and global visual classification tokens, visual-to-audio directional cross-attention, residual addition, and layer normalization.
- A 512-to-256-to-2 classifier for the full model.
- Adam and all settings recorded in `configs/paper.yaml`.

## Reference-implementation choices not uniquely identified by the paper

- `visual_hidden_channels: 373`.
- Two Conv1D layers inside each residual TCN block.
- Eight attention heads.
- Attention and TCN dropout 0.1 and classifier dropout 0.3.
- ReLU in the classifier.

These choices are fixed in the released configuration so an independent user can execute the repository without guessing. Under the implemented two-convolution residual block without additional TCN batch normalization, the analytical trainable-parameter counts are 4,830,570 (global/local), 5,094,506 (serial), and 5,160,042 (full), which round exactly to the manuscript table. That agreement constrains the reconstruction but does not prove identity with an unavailable original source tree. If the authors possess the actual training source, its exact values should replace these reference defaults before archival release.

## Temporal-step metadata

The paper requires restriction to the common retained source-video interval before fixed-length standardization. The public features may already embody that restriction. The loader therefore supports both cases through `features_already_common_interval`. When raw feature sequences are not pre-aligned, provide accurate `audio_step_seconds` and `visual_step_seconds` in the manifest. Do not infer step durations merely to make shapes match.

## Reproducibility interpretation

The manuscript-reference CSV/JSON files are a verifiable transcription of reported results. Only newly generated output under `outputs/` is evidence of a rerun. A numerically close result is expected, not guaranteed, because GPU kernels, dataset revisions, and missing original implementation details may affect optimization.
