# AI-guided experiment protocol

Use this checklist when asking an AI coding agent to reproduce or extend the experiments.

## Non-negotiable invariants

1. Never place samples from one participant in more than one outer fold.
2. For test fold `k`, use fold `k mod 10 + 1` for validation and the other eight folds for training.
3. Fit normalization statistics on training folds only.
4. Keep padded positions at zero and propagate masks through convolution, pooling, and attention.
5. Pool chronological positions only; prepend classification tokens after local/global resolution construction and never average them.
6. Select a checkpoint using validation weighted F1; inspect the outer test fold only after selection.
7. Run seeds 0-4 for every fold and architecture.
8. Keep all model/hyperparameter changes explicit in a new YAML file; never silently modify `configs/paper.yaml`.

## Recommended staged workflow

```bash
bash run_smoke_test.sh
python scripts/audit_data.py --manifest data/lmvd_manifest.csv --data-root /path/to/data --output outputs/data_audit.json
python scripts/make_folds.py --manifest data/lmvd_manifest.csv --output folds/fold_assignments.csv --summary folds/fold_composition_generated.csv --seed 2026 --expected-summary folds/reported_fold_composition.csv
bash run_paper_protocol.sh /path/to/data
python scripts/verify_repository.py
```

Before the 200 full runs, execute one real-data fold and compare tensor lengths, parameter counts, peak memory, loss stability, and saved prediction schema. Do not tune on the test fold when a mismatch appears.

## Minimal AI-agent completion criteria

Ask the agent to return:

- the resolved YAML and software/hardware inventory;
- a fold-leakage assertion result;
- per-epoch training/validation history;
- one checkpoint chosen by validation weighted F1;
- seed-level test predictions, followed by seed-averaged OOF predictions;
- fold-level and aggregate metrics with sample standard deviation across folds;
- the paired full-versus-global statistical report;
- efficiency measurements under batch size 1, 50 warm-up passes, and 200 timed passes;
- a list of deviations from this repository.

Reference logs show the expected file and message format. They must never be relabeled as raw run logs.
