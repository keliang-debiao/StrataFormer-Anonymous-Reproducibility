# Manuscript reference artifacts

These machine-readable files transcribe the final tables and numerical statements in the anonymized manuscript. Percentages are stored on a 0-100 scale. They support consistency checks and reference-log generation; they are not newly computed experimental outputs.

- `main_results.csv`: mean and sample standard deviation across ten outer folds.
- `seed_accuracy.csv`: cross-fold mean accuracy for each training seed.
- `fold_accuracy.csv`: matched fold-level accuracy means used for the paired test.
- `paired_statistics.json`: two-sided paired test reported for full versus global-only.
- `oof_confusion.json`: pooled out-of-fold confusion counts and derived per-class metrics.
- `efficiency.csv`: batch-one inference profile on an RTX 4090 with AMP.
- `padding_distribution.csv`: fixed-length preprocessing outcomes.
- `baselines.csv`: Table 4 accuracy, precision, recall, and F1; cited baseline values are descriptive because identical predictions were unavailable for matched inference.
