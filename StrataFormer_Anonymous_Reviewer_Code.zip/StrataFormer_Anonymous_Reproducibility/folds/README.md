# Fold files

`reported_fold_composition.csv` contains the aggregate fold composition stated in the manuscript. It does not identify samples or participants.

Exact manuscript reproduction additionally requires `fold_assignments.csv` with these columns:

```text
sample_id,participant_id,label,fold
```

Each participant must occur in exactly one outer fold. This file is intentionally not fabricated from aggregate counts. Create it from the real LMVD manifest with `scripts/make_folds.py`, or insert the author-verified assignment used for the reported runs. The generator canonically sorts participant and sample identifiers before invoking the pinned scikit-learn splitter with seed 2026, so input CSV row order cannot change the result. Equality of fold totals alone nevertheless does not prove equality of sample membership.
