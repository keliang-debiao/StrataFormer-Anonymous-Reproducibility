#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from strataformer.splits import validate_manifest


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit feature shapes and fixed-length outcomes.")
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--data-root", required=True, type=Path)
    parser.add_argument("--audio-target", type=int, default=186)
    parser.add_argument("--visual-target", type=int, default=915)
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args()


def disposition(length: int, target: int) -> str:
    if length < target:
        return "padded"
    if length == target:
        return "exact"
    return "truncated"


def main() -> None:
    args = parse_args()
    frame = pd.read_csv(args.manifest, dtype={"sample_id": str, "participant_id": str})
    validate_manifest(frame)
    counts = {"audio": {"padded": 0, "exact": 0, "truncated": 0}, "visual": {"padded": 0, "exact": 0, "truncated": 0}}
    nonfinite = {"audio": 0, "visual": 0}
    for row in frame.itertuples(index=False):
        audio = np.load(args.data_root / str(row.audio_path), mmap_mode="r", allow_pickle=False)
        visual = np.load(args.data_root / str(row.visual_path), mmap_mode="r", allow_pickle=False)
        if audio.ndim != 2 or audio.shape[1] != 128:
            raise ValueError(f"Bad audio shape for {row.sample_id}: {audio.shape}")
        if visual.ndim != 2 or visual.shape[1] != 171:
            raise ValueError(f"Bad visual shape for {row.sample_id}: {visual.shape}")
        counts["audio"][disposition(len(audio), args.audio_target)] += 1
        counts["visual"][disposition(len(visual), args.visual_target)] += 1
        nonfinite["audio"] += int((~np.isfinite(audio)).sum())
        nonfinite["visual"] += int((~np.isfinite(visual)).sum())
    payload = {
        "samples": len(frame),
        "participants": int(frame.participant_id.nunique()),
        "class_counts": {str(key): int(value) for key, value in frame.label.value_counts().sort_index().items()},
        "fixed_length_outcomes": counts,
        "nonfinite_values": nonfinite,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
