#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


NOTICE = "REFERENCE LOG — NOT A RAW TRAINING TRANSCRIPT"


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    artifacts = root / "artifacts" / "manuscript_reference"
    output = root / "logs" / "reference"
    output.mkdir(parents=True, exist_ok=True)

    results = pd.read_csv(artifacts / "main_results.csv")
    lines = [NOTICE, "source=anonymized_manuscript_tables", "scale=percentage"]
    for row in results.itertuples(index=False):
        lines.append(
            f"variant={row.variant} accuracy={row.accuracy_mean:.2f}+/-{row.accuracy_sd:.2f} "
            f"weighted_f1={row.weighted_f1_mean:.2f}+/-{row.weighted_f1_sd:.2f} "
            f"macro_f1={row.macro_f1_mean:.2f}+/-{row.macro_f1_sd:.2f} "
            f"balanced_accuracy={row.balanced_accuracy_mean:.2f}+/-{row.balanced_accuracy_sd:.2f}"
        )
    (output / "manuscript_reference_summary.log").write_text("\n".join(lines) + "\n", encoding="utf-8")

    folds = pd.read_csv(artifacts / "fold_accuracy.csv")
    lines = [NOTICE, "source=reported_matched_fold_means", "scale=percentage_points"]
    for _, row in folds.iterrows():
        lines.append(
            f"fold={int(row['fold']):02d} local={row['local']:.2f} global={row['global']:.2f} "
            f"serial={row['serial']:.2f} full={row['full']:.2f} full_minus_global={row['full_minus_global']:+.2f}"
        )
    (output / "fold_accuracy_reference.log").write_text("\n".join(lines) + "\n", encoding="utf-8")

    efficiency = pd.read_csv(artifacts / "efficiency.csv")
    lines = [
        NOTICE,
        "source=reported_efficiency_table",
        "hardware=NVIDIA_RTX_4090 framework=PyTorch_2.5.1 cuda=11.8 amp=true batch_size=1 warmup=50 timed=200 io_excluded=true",
    ]
    for row in efficiency.itertuples(index=False):
        lines.append(
            f"variant={row.variant} parameters_million={row.parameters_million:.2f} "
            f"mean_ms={row.mean_latency_ms:.2f} p95_ms={row.p95_latency_ms:.2f} peak_gb={row.peak_memory_gb:.2f}"
        )
    (output / "efficiency_reference.log").write_text("\n".join(lines) + "\n", encoding="utf-8")

    reference_records = [
        {"record_type": "notice", "message": NOTICE, "purpose": "parser_and_workflow_demonstration_only"},
        {"record_type": "run_start", "dataset": "reference_demo", "variant": "full", "fold": 1, "seed": 0},
        {"record_type": "epoch", "epoch": 1, "learning_rate": 6.67e-7, "train_loss": 0.7012, "validation_weighted_f1": 0.5000},
        {"record_type": "epoch", "epoch": 5, "learning_rate": 3.33e-6, "train_loss": 0.6824, "validation_weighted_f1": 0.5714},
        {"record_type": "epoch", "epoch": 15, "learning_rate": 1.00e-5, "train_loss": 0.6417, "validation_weighted_f1": 0.6667},
        {"record_type": "checkpoint", "epoch": 15, "selection_metric": "validation_weighted_f1"},
        {"record_type": "run_end", "best_epoch": 15, "test_evaluated_after_selection": True, "test_accuracy": 0.7500},
    ]
    with (output / "reference_training_format.jsonl").open("w", encoding="utf-8") as handle:
        for record in reference_records:
            handle.write(json.dumps(record, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
