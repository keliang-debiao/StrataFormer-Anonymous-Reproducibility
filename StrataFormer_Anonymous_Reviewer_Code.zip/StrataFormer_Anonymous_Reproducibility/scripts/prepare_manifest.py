#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from strataformer.splits import validate_manifest


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build the normalized LMVD feature manifest.")
    parser.add_argument("--metadata-csv", required=True, type=Path)
    parser.add_argument("--audio-dir", required=True, type=Path)
    parser.add_argument("--visual-dir", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--sample-column", default="sample_id")
    parser.add_argument("--participant-column", default="participant_id")
    parser.add_argument("--label-column", default="label")
    parser.add_argument("--audio-suffix", default=".npy")
    parser.add_argument("--visual-suffix", default=".npy")
    parser.add_argument("--audio-step-seconds", type=float)
    parser.add_argument("--visual-step-seconds", type=float)
    parser.add_argument("--allow-missing", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    metadata = pd.read_csv(args.metadata_csv)
    required = [args.sample_column, args.participant_column, args.label_column]
    missing = [column for column in required if column not in metadata.columns]
    if missing:
        raise ValueError(f"Metadata is missing source columns: {missing}")
    sample_ids = metadata[args.sample_column].astype(str)
    frame = pd.DataFrame(
        {
            "sample_id": sample_ids,
            "participant_id": metadata[args.participant_column].astype(str),
            "label": pd.to_numeric(metadata[args.label_column], errors="raise").astype(int),
            "audio_path": [str(args.audio_dir / f"{value}{args.audio_suffix}") for value in sample_ids],
            "visual_path": [str(args.visual_dir / f"{value}{args.visual_suffix}") for value in sample_ids],
        }
    )
    if args.audio_step_seconds is not None:
        frame["audio_step_seconds"] = args.audio_step_seconds
    if args.visual_step_seconds is not None:
        frame["visual_step_seconds"] = args.visual_step_seconds
    validate_manifest(frame)
    absent = []
    for column in ("audio_path", "visual_path"):
        absent.extend(path for path in frame[column] if not Path(path).is_file())
    if absent and not args.allow_missing:
        raise FileNotFoundError(f"Missing {len(absent)} feature files; first entries: {absent[:5]}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(args.output, index=False)
    print(f"Wrote {len(frame)} samples from {frame.participant_id.nunique()} participants to {args.output}")


if __name__ == "__main__":
    main()
