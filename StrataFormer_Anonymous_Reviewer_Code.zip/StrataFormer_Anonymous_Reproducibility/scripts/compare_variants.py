#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from strataformer.statistics import paired_fold_analysis
from strataformer.utils import write_json


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Matched-fold full-versus-comparator test.")
    parser.add_argument("--full-fold-csv", required=True, type=Path)
    parser.add_argument("--global-fold-csv", required=True, type=Path)
    parser.add_argument("--metric", default="accuracy")
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    full = pd.read_csv(args.full_fold_csv)[["fold", args.metric]].rename(columns={args.metric: "full"})
    comparator = pd.read_csv(args.global_fold_csv)[["fold", args.metric]].rename(columns={args.metric: "comparator"})
    matched = full.merge(comparator, on="fold", how="inner", validate="one_to_one").sort_values("fold")
    if len(matched) != len(full) or len(matched) != len(comparator):
        raise ValueError("Fold identifiers do not match between variants")
    payload = {"metric": args.metric, **paired_fold_analysis(matched.full.to_numpy(), matched.comparator.to_numpy())}
    write_json(payload, args.output)
    print(pd.Series(payload).to_string())


if __name__ == "__main__":
    main()
