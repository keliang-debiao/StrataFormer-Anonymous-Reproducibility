#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create non-clinical toy tensors for smoke tests.")
    parser.add_argument("--output-dir", type=Path, default=Path("data/toy"))
    parser.add_argument("--participants", type=int, default=12)
    parser.add_argument("--samples-per-participant", type=int, default=1)
    parser.add_argument("--seed", type=int, default=2026)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.participants < 6 or args.participants % 2:
        raise ValueError("Use an even participant count of at least six")
    rng = np.random.default_rng(args.seed)
    audio_dir = args.output_dir / "audio"
    visual_dir = args.output_dir / "visual"
    audio_dir.mkdir(parents=True, exist_ok=True)
    visual_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    sample_number = 0
    for participant_number in range(args.participants):
        label = participant_number % 2
        participant_id = f"toy_participant_{participant_number:03d}"
        for _ in range(args.samples_per_participant):
            sample_id = f"toy_sample_{sample_number:04d}"
            audio_length = int(rng.integers(12, 33))
            visual_length = int(rng.integers(36, 85))
            audio = rng.normal(label * 0.05, 1.0, size=(audio_length, 128)).astype(np.float32)
            visual = rng.normal(label * 0.05, 1.0, size=(visual_length, 171)).astype(np.float32)
            np.save(audio_dir / f"{sample_id}.npy", audio)
            np.save(visual_dir / f"{sample_id}.npy", visual)
            rows.append(
                {
                    "sample_id": sample_id,
                    "participant_id": participant_id,
                    "label": label,
                    "audio_path": f"audio/{sample_id}.npy",
                    "visual_path": f"visual/{sample_id}.npy",
                }
            )
            sample_number += 1
    pd.DataFrame(rows).to_csv(args.output_dir / "manifest.csv", index=False)
    print(f"Created {len(rows)} toy samples at {args.output_dir}")


if __name__ == "__main__":
    main()
