#!/usr/bin/env python3
from __future__ import annotations

import json
import hashlib
import re
from pathlib import Path

import numpy as np
import pandas as pd

from strataformer.architecture import analytical_parameter_counts, sequence_contract
from strataformer.config import load_config
from strataformer.statistics import paired_fold_analysis


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    required = [
        "README.md",
        "FILE_MANIFEST.sha256",
        "REPRODUCIBILITY_SCOPE.md",
        "REVIEWER_GUIDE.md",
        "configs/paper.yaml",
        "data/README.md",
        "docs/CONFIGURATION_NOTES.md",
        "folds/reported_fold_composition.csv",
        "src/strataformer/models/model.py",
        "scripts/train_cv.py",
        "scripts/evaluate_oof.py",
        "scripts/compare_variants.py",
        "scripts/profile_models.py",
        "scripts/export_attention.py",
        "scripts/architecture_audit.py",
        "artifacts/manuscript_reference/architecture_contract.json",
        "artifacts/manuscript_reference/main_results.csv",
        "logs/reference/manuscript_reference_summary.log",
        "logs/reference/reference_training_format.jsonl",
    ]
    errors: list[str] = []
    warnings: list[str] = []
    for relative in required:
        if not (root / relative).is_file():
            errors.append(f"missing required file: {relative}")

    dataset = json.loads((root / "artifacts/manuscript_reference/dataset_summary.json").read_text(encoding="utf-8"))
    folds = pd.read_csv(root / "folds/reported_fold_composition.csv")
    expected_totals = {
        "participants": int(folds.participants.sum()),
        "samples": int(folds.samples.sum()),
        "depressed_samples": int(folds.depressed.sum()),
        "non_depressed_samples": int(folds.non_depressed.sum()),
    }
    for key, value in expected_totals.items():
        if int(dataset[key]) != value:
            errors.append(f"fold total mismatch for {key}: {value} != {dataset[key]}")

    padding = pd.read_csv(root / "artifacts/manuscript_reference/padding_distribution.csv")
    for modality, group in padding.groupby("modality"):
        if int(group["count"].sum()) != int(dataset["samples"]):
            errors.append(f"padding counts for {modality} do not sum to sample total")
        if not np.isclose(group["percentage"].sum(), 100.0, atol=0.02):
            errors.append(f"padding percentages for {modality} do not sum to 100")

    fold_accuracy = pd.read_csv(root / "artifacts/manuscript_reference/fold_accuracy.csv")
    seed_accuracy = pd.read_csv(root / "artifacts/manuscript_reference/seed_accuracy.csv")
    main_results = pd.read_csv(root / "artifacts/manuscript_reference/main_results.csv").set_index("variant")
    for variant in ("local", "global", "serial", "full"):
        fold_mean = float(fold_accuracy[variant].mean())
        fold_sd = float(fold_accuracy[variant].std(ddof=1))
        seed_mean = float(seed_accuracy[variant].mean())
        if not np.isclose(fold_mean, main_results.loc[variant, "accuracy_mean"], atol=0.015):
            errors.append(f"fold mean inconsistent for {variant}")
        if not np.isclose(fold_sd, main_results.loc[variant, "accuracy_sd"], atol=0.015):
            errors.append(f"fold SD inconsistent for {variant}")
        if not np.isclose(seed_mean, main_results.loc[variant, "accuracy_mean"], atol=0.015):
            errors.append(f"seed mean inconsistent for {variant}")

    calculated = paired_fold_analysis(
        fold_accuracy["full"].to_numpy(), fold_accuracy["global"].to_numpy()
    )
    reported = json.loads((root / "artifacts/manuscript_reference/paired_statistics.json").read_text(encoding="utf-8"))
    comparisons = {
        "shapiro_w": "shapiro_w",
        "shapiro_p": "shapiro_p",
        "paired_t": "paired_t",
        "paired_p": "paired_p",
        "cohens_dz": "cohens_dz",
    }
    for calculated_key, reported_key in comparisons.items():
        if not np.isclose(calculated[calculated_key], reported[reported_key], atol=0.002):
            errors.append(f"paired statistic mismatch: {reported_key}")

    confusion = json.loads((root / "artifacts/manuscript_reference/oof_confusion.json").read_text(encoding="utf-8"))
    if confusion["tn"] + confusion["fp"] + confusion["fn"] + confusion["tp"] != dataset["samples"]:
        errors.append("OOF confusion counts do not sum to sample total")

    config = load_config(root / "configs/paper.yaml")
    contract = sequence_contract(config)
    expected_contract = {
        "visual_local_chronological_positions": 114,
        "visual_local_queries_with_cls": 115,
        "audio_global_positions": 31,
        "visual_global_queries_with_cls": 29,
        "local_attention_pairs": 21390,
        "global_attention_pairs": 899,
        "full_attention_pairs": 22289,
    }
    for key, expected in expected_contract.items():
        if contract[key] != expected:
            errors.append(f"architecture contract mismatch for {key}")
    parameter_counts = analytical_parameter_counts(config)
    efficiency = pd.read_csv(root / "artifacts/manuscript_reference/efficiency.csv").set_index("variant")
    for variant, count in parameter_counts.items():
        if round(count / 1e6, 2) != float(efficiency.loc[variant, "parameters_million"]):
            errors.append(f"parameter count does not round to reported value for {variant}")

    text_extensions = {".md", ".py", ".yaml", ".yml", ".toml", ".csv", ".json", ".sh", ".cff", ".txt", ".log", ".jsonl"}
    forbidden_patterns = {
        "Chinese author name": re.compile("张" + "佩"),
        "workspace absolute path": re.compile(
            "/work" + "space/|/ho" + "me/|/Us" + "ers/"
        ),
        "Windows user path": re.compile(r"[A-Za-z]:\\\\Users\\\\"),
        "email address": re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"),
    }
    for path in root.rglob("*"):
        if path.is_file() and path.suffix.lower() in text_extensions:
            content = path.read_text(encoding="utf-8", errors="replace")
            for label, pattern in forbidden_patterns.items():
                if pattern.search(content):
                    errors.append(f"anonymity scan found {label} in {path.relative_to(root)}")

    for path in (root / "logs" / "reference").glob("*"):
        if path.is_file() and "REFERENCE LOG" not in path.read_text(encoding="utf-8", errors="replace"):
            errors.append(f"reference log lacks provenance notice: {path.name}")

    if not (root / "folds/fold_assignments.csv").exists():
        warnings.append("author-verified folds/fold_assignments.csv is not included")

    checksum_path = root / "FILE_MANIFEST.sha256"
    if checksum_path.is_file():
        for line in checksum_path.read_text(encoding="utf-8").splitlines():
            expected_hash, relative = line.split(maxsplit=1)
            target = root / relative.removeprefix("./")
            if not target.is_file():
                errors.append(f"checksum target is missing: {relative}")
                continue
            actual_hash = hashlib.sha256(target.read_bytes()).hexdigest()
            if actual_hash != expected_hash:
                errors.append(f"checksum mismatch: {relative}")
    if warnings:
        for warning in warnings:
            print(f"WARNING: {warning}")
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        raise SystemExit(f"Repository audit failed with {len(errors)} error(s)")
    print("Repository audit passed: structure, numerical consistency, log labeling, and anonymity checks are clean.")


if __name__ == "__main__":
    main()
