#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from strataformer.config import load_config
from strataformer.data import LMVDDataset, ModalityStats
from strataformer.models import build_model


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Export head-wise attention for one anonymous sample.")
    parser.add_argument("--config", type=Path, default=Path("configs/paper.yaml"))
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--data-root", required=True, type=Path)
    parser.add_argument("--training-statistics", required=True, type=Path)
    parser.add_argument("--sample-id", required=True)
    parser.add_argument("--variant", default="full", choices=["full", "local", "global", "serial"])
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--device", default="cpu", choices=["cpu", "cuda"])
    return parser.parse_args()


def main() -> None:
    import torch

    args = parse_args()
    config = load_config(args.config)
    frame = pd.read_csv(args.manifest, dtype={"sample_id": str, "participant_id": str})
    selected = frame[frame.sample_id == str(args.sample_id)].copy()
    if len(selected) != 1:
        raise ValueError(f"Expected exactly one row for sample_id={args.sample_id!r}, found {len(selected)}")
    stats = ModalityStats.load(args.training_statistics)
    data = config["data"]
    dataset = LMVDDataset(
        selected,
        args.data_root,
        stats,
        audio_dim=int(data["audio_dim"]),
        visual_dim=int(data["visual_dim"]),
        audio_target=int(data["audio_target_length"]),
        visual_target=int(data["visual_target_length"]),
        restrict_to_common_interval=bool(data["restrict_to_common_interval"]),
        features_already_common_interval=bool(data["features_already_common_interval"]),
    )
    item = dataset[0]
    device = torch.device(args.device)
    model = build_model(config, args.variant).to(device)
    model.load_state_dict(torch.load(args.checkpoint, map_location=device, weights_only=True))
    model.eval()
    with torch.inference_mode():
        result = model(
            item["audio"].unsqueeze(0).to(device),
            item["visual"].unsqueeze(0).to(device),
            item["audio_mask"].unsqueeze(0).to(device),
            item["visual_mask"].unsqueeze(0).to(device),
            return_attention=True,
        )
    payload = {
        "sample_id": np.asarray([str(args.sample_id)]),
        "label": np.asarray([int(item["label"])]),
        "logits": result["logits"].detach().cpu().numpy(),
        "audio_mask": item["audio_mask"].numpy(),
        "visual_input_mask": item["visual_mask"].numpy(),
    }
    for branch, weights in result["attention"].items():
        if weights is not None:
            payload[f"{branch}_attention_heads"] = weights.detach().cpu().numpy()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.output, **payload)
    print(f"Saved {sorted(payload)} to {args.output}")


if __name__ == "__main__":
    main()
