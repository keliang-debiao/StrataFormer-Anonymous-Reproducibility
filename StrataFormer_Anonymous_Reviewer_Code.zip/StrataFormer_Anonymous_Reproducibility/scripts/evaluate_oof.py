#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from strataformer.metrics import classification_metrics, summarize_rows
from strataformer.utils import write_json


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Aggregate seed predictions into OOF metrics.")
    parser.add_argument("--predictions-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--expected-seeds", type=int)
    parser.add_argument("--expected-folds", type=int)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    paths = sorted(args.predictions_dir.rglob("test_predictions.csv"))
    if not paths:
        raise FileNotFoundError(f"No test_predictions.csv files below {args.predictions_dir}")
    raw = pd.concat([pd.read_csv(path, dtype={"sample_id": str}) for path in paths], ignore_index=True)
    consistency = raw.groupby("sample_id").agg(label_count=("label", "nunique"), fold_count=("fold", "nunique"))
    if (consistency > 1).any().any():
        raise ValueError("A sample has inconsistent labels or test folds across seeds")
    if args.expected_seeds is not None:
        seed_counts = raw.groupby("sample_id")["seed"].nunique()
        if not (seed_counts == args.expected_seeds).all():
            raise ValueError("At least one sample does not have the expected number of seed predictions")
    if args.expected_folds is not None and raw["fold"].nunique() != args.expected_folds:
        raise ValueError("Prediction files do not contain the expected number of outer folds")
    oof = (
        raw.groupby("sample_id", as_index=False)
        .agg(
            label=("label", "first"),
            fold=("fold", "first"),
            probability_0=("probability_0", "mean"),
            probability_1=("probability_1", "mean"),
            seed_repetitions=("seed", "nunique"),
        )
        .sort_values(["fold", "sample_id"])
    )
    oof["prediction"] = (oof.probability_1 > oof.probability_0).astype(int)
    metric_keys = [
        "accuracy",
        "weighted_precision",
        "weighted_recall",
        "weighted_f1",
        "macro_f1",
        "balanced_accuracy",
    ]
    seed_fold_rows = []
    for (fold, seed), subset in raw.groupby(["fold", "seed"], sort=True):
        metrics = classification_metrics(subset.label, subset.prediction)
        seed_fold_rows.append(
            {"fold": int(fold), "seed": int(seed), **{key: metrics[key] for key in metric_keys}}
        )
    seed_fold_frame = pd.DataFrame(seed_fold_rows)
    fold_frame = seed_fold_frame.groupby("fold", as_index=False)[metric_keys].mean()
    fold_rows = fold_frame.to_dict(orient="records")
    overall = classification_metrics(oof.label, oof.prediction)
    summary = summarize_rows(
        fold_rows,
        ["accuracy", "weighted_f1", "macro_f1", "balanced_accuracy"],
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    oof.to_csv(args.output_dir / "oof_predictions.csv", index=False)
    seed_fold_frame.to_csv(args.output_dir / "seed_fold_metrics.csv", index=False)
    fold_frame.to_csv(args.output_dir / "fold_metrics.csv", index=False)
    write_json({"overall_oof": overall, "fold_mean_and_sd": summary}, args.output_dir / "summary.json")
    print(f"Aggregated {len(raw)} rows into {len(oof)} OOF predictions")
    print(pd.Series(overall).to_string())


if __name__ == "__main__":
    main()
