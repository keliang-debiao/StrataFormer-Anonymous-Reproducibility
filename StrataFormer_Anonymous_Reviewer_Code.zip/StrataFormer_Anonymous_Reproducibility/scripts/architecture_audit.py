#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from strataformer.architecture import analytical_parameter_counts, sequence_contract
from strataformer.config import load_config


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit architecture lengths and parameter counts without a GPU.")
    parser.add_argument("--config", type=Path, default=Path("configs/paper.yaml"))
    parser.add_argument("--output", type=Path)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = load_config(args.config)
    counts = analytical_parameter_counts(config)
    payload = {
        "sequence_contract": sequence_contract(config),
        "trainable_parameters": counts,
        "trainable_parameters_million": {key: round(value / 1e6, 6) for key, value in counts.items()},
    }
    text = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    print(text, end="")


if __name__ == "__main__":
    main()
