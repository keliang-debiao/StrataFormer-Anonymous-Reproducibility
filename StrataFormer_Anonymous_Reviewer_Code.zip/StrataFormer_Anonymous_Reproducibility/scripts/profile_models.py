#!/usr/bin/env python3
from __future__ import annotations

import argparse
import time
from pathlib import Path

import numpy as np
import pandas as pd

from strataformer.config import load_config
from strataformer.models import build_model


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Profile parameters, latency, and peak CUDA memory.")
    parser.add_argument("--config", type=Path, default=Path("configs/paper.yaml"))
    parser.add_argument("--device", default="cuda", choices=["cpu", "cuda"])
    parser.add_argument("--warmup", type=int)
    parser.add_argument("--iterations", type=int)
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args()


def main() -> None:
    import torch

    args = parse_args()
    config = load_config(args.config)
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA profiling requested but CUDA is unavailable")
    warmup = args.warmup or int(config["profiling"]["warmup_iterations"])
    iterations = args.iterations or int(config["profiling"]["timed_iterations"])
    data = config["data"]
    batch_size = int(config["profiling"]["batch_size"])
    audio = torch.randn(batch_size, int(data["audio_target_length"]), int(data["audio_dim"]), device=device)
    visual = torch.randn(batch_size, int(data["visual_target_length"]), int(data["visual_dim"]), device=device)
    audio_mask = torch.ones(audio.shape[:2], dtype=torch.bool, device=device)
    visual_mask = torch.ones(visual.shape[:2], dtype=torch.bool, device=device)
    rows = []
    for variant in ("global", "local", "serial", "full"):
        model = build_model(config, variant).to(device).eval()
        if device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(device)
        durations = []
        with torch.inference_mode():
            for iteration in range(warmup + iterations):
                if device.type == "cuda":
                    torch.cuda.synchronize(device)
                start = time.perf_counter()
                with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=device.type == "cuda"):
                    model(audio, visual, audio_mask, visual_mask)
                if device.type == "cuda":
                    torch.cuda.synchronize(device)
                elapsed_ms = (time.perf_counter() - start) * 1000.0
                if iteration >= warmup:
                    durations.append(elapsed_ms)
        rows.append(
            {
                "variant": variant,
                "parameters_million": sum(parameter.numel() for parameter in model.parameters()) / 1e6,
                "mean_latency_ms": float(np.mean(durations)),
                "p95_latency_ms": float(np.percentile(durations, 95)),
                "peak_memory_gb": torch.cuda.max_memory_allocated(device) / 1e9 if device.type == "cuda" else np.nan,
            }
        )
        del model
    result = pd.DataFrame(rows)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.output, index=False)
    print(result.to_string(index=False))


if __name__ == "__main__":
    main()
