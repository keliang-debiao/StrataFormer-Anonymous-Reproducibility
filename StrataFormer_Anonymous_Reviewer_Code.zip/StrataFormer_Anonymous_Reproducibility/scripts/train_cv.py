#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from strataformer.config import load_config, save_config
from strataformer.data import LMVDDataset, fit_modality_stats
from strataformer.engine import evaluate, fit_with_early_stopping
from strataformer.models import build_model
from strataformer.splits import load_and_join_manifest, outer_split_folds
from strataformer.utils import parse_int_list, seed_worker, set_seed, write_json


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train participant-disjoint StrataFormer folds.")
    parser.add_argument("--config", type=Path, default=Path("configs/paper.yaml"))
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--fold-assignments", type=Path, required=True)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--variant", choices=["full", "local", "global", "serial"])
    parser.add_argument("--folds", help="Comma-separated one-based folds; default: all")
    parser.add_argument("--seeds", help="Comma-separated seeds; default: config list")
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    return parser.parse_args()


def select_device(name: str):
    import torch

    if name == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if name == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    return torch.device(name)


def make_dataset(frame: pd.DataFrame, root: Path, stats, config: dict):
    data = config["data"]
    return LMVDDataset(
        frame,
        root,
        stats,
        audio_dim=int(data["audio_dim"]),
        visual_dim=int(data["visual_dim"]),
        audio_target=int(data["audio_target_length"]),
        visual_target=int(data["visual_target_length"]),
        restrict_to_common_interval=bool(data["restrict_to_common_interval"]),
        features_already_common_interval=bool(data["features_already_common_interval"]),
    )


def make_loader(dataset, config: dict, shuffle: bool, seed: int):
    import torch

    generator = torch.Generator()
    generator.manual_seed(seed)
    return torch.utils.data.DataLoader(
        dataset,
        batch_size=int(config["training"]["batch_size"]),
        shuffle=shuffle,
        num_workers=int(config["data"]["num_workers"]),
        pin_memory=torch.cuda.is_available(),
        persistent_workers=int(config["data"]["num_workers"]) > 0,
        generator=generator,
        worker_init_fn=seed_worker,
    )


def main() -> None:
    import torch

    args = parse_args()
    config = load_config(args.config)
    variant = args.variant or str(config["model"]["variant"])
    config["model"]["variant"] = variant
    num_folds = int(config["experiment"]["num_folds"])
    folds = parse_int_list(args.folds, list(range(1, num_folds + 1)))
    seeds = parse_int_list(args.seeds, [int(value) for value in config["experiment"]["training_seeds"]])
    output_root = args.output_root or Path(config["experiment"]["output_dir"])
    output_root = output_root / variant
    output_root.mkdir(parents=True, exist_ok=True)
    save_config(config, output_root / "resolved_config.yaml")
    frame = load_and_join_manifest(args.manifest, args.fold_assignments)
    device = select_device(args.device)
    print(f"variant={variant} device={device} folds={folds} seeds={seeds}")

    for test_fold in folds:
        train_folds, validation_fold, _ = outer_split_folds(test_fold, num_folds)
        train_frame = frame[frame.fold.isin(train_folds)].copy()
        validation_frame = frame[frame.fold == validation_fold].copy()
        test_frame = frame[frame.fold == test_fold].copy()
        participant_sets = [set(part.participant_id) for part in (train_frame, validation_frame, test_frame)]
        if any(participant_sets[i] & participant_sets[j] for i, j in ((0, 1), (0, 2), (1, 2))):
            raise RuntimeError("Participant leakage detected after outer split")

        fold_dir = output_root / f"fold_{test_fold:02d}"
        stats_path = fold_dir / "training_statistics.npz"
        stats = fit_modality_stats(
            train_frame,
            args.data_root,
            audio_dim=int(config["data"]["audio_dim"]),
            visual_dim=int(config["data"]["visual_dim"]),
            audio_target=int(config["data"]["audio_target_length"]),
            visual_target=int(config["data"]["visual_target_length"]),
            eps=float(config["data"]["normalization_eps"]),
            restrict_to_common_interval=bool(config["data"]["restrict_to_common_interval"]),
            features_already_common_interval=bool(config["data"]["features_already_common_interval"]),
        )
        stats.save(stats_path)
        train_dataset = make_dataset(train_frame, args.data_root, stats, config)
        validation_dataset = make_dataset(validation_frame, args.data_root, stats, config)
        test_dataset = make_dataset(test_frame, args.data_root, stats, config)

        for seed in seeds:
            set_seed(seed, bool(config["experiment"]["deterministic"]))
            seed_dir = fold_dir / f"seed_{seed}"
            seed_dir.mkdir(parents=True, exist_ok=True)
            train_loader = make_loader(train_dataset, config, shuffle=True, seed=seed)
            validation_loader = make_loader(validation_dataset, config, shuffle=False, seed=seed)
            test_loader = make_loader(test_dataset, config, shuffle=False, seed=seed)
            model = build_model(config, variant).to(device)
            parameter_count = sum(parameter.numel() for parameter in model.parameters())
            history = fit_with_early_stopping(
                model,
                train_loader,
                validation_loader,
                config,
                device,
                seed_dir / "best_model.pt",
            )
            test_metrics, probabilities, labels, sample_ids = evaluate(model, test_loader, device)
            prediction_frame = pd.DataFrame(
                {
                    "sample_id": sample_ids,
                    "label": labels.astype(int),
                    "probability_0": probabilities[:, 0],
                    "probability_1": probabilities[:, 1],
                    "prediction": probabilities.argmax(axis=1),
                    "fold": test_fold,
                    "seed": seed,
                    "variant": variant,
                }
            )
            prediction_frame.to_csv(seed_dir / "test_predictions.csv", index=False)
            pd.DataFrame(history).to_csv(seed_dir / "history.csv", index=False)
            payload = {
                "variant": variant,
                "fold": test_fold,
                "validation_fold": validation_fold,
                "training_folds": train_folds,
                "seed": seed,
                "device": str(device),
                "parameter_count": parameter_count,
                "best_epoch": int(max(history, key=lambda row: row["validation_weighted_f1"])["epoch"]),
                "test_metrics": test_metrics,
            }
            write_json(payload, seed_dir / "metrics.json")
            print(json.dumps(payload, sort_keys=True))
            del model
            if device.type == "cuda":
                torch.cuda.empty_cache()


if __name__ == "__main__":
    main()
