#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from strataformer.splits import fold_composition, make_grouped_folds


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create deterministic participant-disjoint folds.")
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--summary", required=True, type=Path)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--num-folds", type=int, default=10)
    parser.add_argument("--expected-summary", type=Path)
    parser.add_argument("--require-summary-match", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    manifest = pd.read_csv(args.manifest, dtype={"sample_id": str, "participant_id": str})
    assignments = make_grouped_folds(manifest, args.num_folds, args.seed)
    summary = fold_composition(assignments)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    assignments.to_csv(args.output, index=False)
    summary.to_csv(args.summary, index=False)
    print(summary.to_string(index=False))
    if args.expected_summary:
        expected = pd.read_csv(args.expected_summary)
        columns = ["fold", "participants", "samples", "depressed", "non_depressed"]
        matches = summary[columns].reset_index(drop=True).equals(expected[columns].reset_index(drop=True))
        print(f"Reported fold-composition match: {matches}")
        if args.require_summary_match and not matches:
            raise SystemExit("Generated composition does not match the author-reported summary")


if __name__ == "__main__":
    main()
