from __future__ import annotations

import math
from pathlib import Path
from typing import Any

import numpy as np

from .metrics import classification_metrics, probabilities_to_predictions


def make_epoch_scheduler(optimizer, max_epochs: int, warmup_epochs: int):
    from torch.optim.lr_scheduler import LambdaLR

    def multiplier(epoch_index: int) -> float:
        completed = epoch_index + 1
        if warmup_epochs > 0 and completed <= warmup_epochs:
            return completed / warmup_epochs
        cosine_epochs = max(max_epochs - warmup_epochs, 1)
        progress = min(max((completed - warmup_epochs) / cosine_epochs, 0.0), 1.0)
        return 0.5 * (1.0 + math.cos(math.pi * progress))

    return LambdaLR(optimizer, lr_lambda=multiplier)


def _move_batch(batch: dict[str, Any], device):
    tensor_keys = ("audio", "visual", "audio_mask", "visual_mask", "label")
    return {key: batch[key].to(device, non_blocking=True) for key in tensor_keys}


def run_training_epoch(model, loader, optimizer, scaler, device, clip_norm: float) -> float:
    import torch

    model.train()
    total_loss = 0.0
    total_items = 0
    amp_enabled = scaler.is_enabled()
    for raw_batch in loader:
        batch = _move_batch(raw_batch, device)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=amp_enabled):
            logits = model(
                batch["audio"],
                batch["visual"],
                batch["audio_mask"],
                batch["visual_mask"],
            )["logits"]
            loss = torch.nn.functional.cross_entropy(logits, batch["label"])
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), clip_norm)
        scaler.step(optimizer)
        scaler.update()
        batch_size = int(batch["label"].shape[0])
        total_loss += float(loss.detach()) * batch_size
        total_items += batch_size
    return total_loss / max(total_items, 1)


def predict(model, loader, device) -> tuple[np.ndarray, np.ndarray, list[str]]:
    import torch

    model.eval()
    probability_batches = []
    label_batches = []
    sample_ids: list[str] = []
    amp_enabled = device.type == "cuda"
    with torch.inference_mode():
        for raw_batch in loader:
            batch = _move_batch(raw_batch, device)
            with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=amp_enabled):
                logits = model(
                    batch["audio"],
                    batch["visual"],
                    batch["audio_mask"],
                    batch["visual_mask"],
                )["logits"]
            probability_batches.append(torch.softmax(logits.float(), dim=-1).cpu().numpy())
            label_batches.append(batch["label"].cpu().numpy())
            sample_ids.extend(str(value) for value in raw_batch["sample_id"])
    return (
        np.concatenate(probability_batches, axis=0),
        np.concatenate(label_batches, axis=0),
        sample_ids,
    )


def evaluate(model, loader, device) -> tuple[dict[str, Any], np.ndarray, np.ndarray, list[str]]:
    probabilities, labels, sample_ids = predict(model, loader, device)
    predictions = probabilities_to_predictions(probabilities)
    metrics = classification_metrics(labels, predictions)
    return metrics, probabilities, labels, sample_ids


def fit_with_early_stopping(
    model,
    train_loader,
    validation_loader,
    config: dict[str, Any],
    device,
    checkpoint_path: str | Path,
) -> list[dict[str, float | int]]:
    import torch

    training = config["training"]
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=float(training["learning_rate"]),
        weight_decay=float(training["weight_decay"]),
        betas=tuple(float(value) for value in training["betas"]),
    )
    scheduler = make_epoch_scheduler(
        optimizer,
        int(training["max_epochs"]),
        int(training["warmup_epochs"]),
    )
    amp_enabled = bool(training["amp"]) and device.type == "cuda"
    scaler = torch.amp.GradScaler(device.type, enabled=amp_enabled)
    checkpoint_path = Path(checkpoint_path)
    checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
    best_score = -float("inf")
    epochs_without_improvement = 0
    history: list[dict[str, float | int]] = []

    for epoch in range(1, int(training["max_epochs"]) + 1):
        train_loss = run_training_epoch(
            model,
            train_loader,
            optimizer,
            scaler,
            device,
            float(training["gradient_clip_norm"]),
        )
        validation_metrics, _, _, _ = evaluate(model, validation_loader, device)
        score = float(validation_metrics[str(training["checkpoint_metric"])])
        history.append(
            {
                "epoch": epoch,
                "learning_rate": float(optimizer.param_groups[0]["lr"]),
                "train_loss": train_loss,
                "validation_weighted_f1": score,
            }
        )
        if score > best_score:
            best_score = score
            epochs_without_improvement = 0
            torch.save(model.state_dict(), checkpoint_path)
        else:
            epochs_without_improvement += 1
        scheduler.step()
        if epochs_without_improvement >= int(training["early_stopping_patience"]):
            break

    model.load_state_dict(torch.load(checkpoint_path, map_location=device, weights_only=True))
    return history
