from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold

REQUIRED_MANIFEST_COLUMNS = {
    "sample_id",
    "participant_id",
    "label",
    "audio_path",
    "visual_path",
}


def validate_manifest(frame: pd.DataFrame) -> None:
    missing = REQUIRED_MANIFEST_COLUMNS - set(frame.columns)
    if missing:
        raise ValueError(f"Manifest is missing required columns: {sorted(missing)}")
    if frame["sample_id"].duplicated().any():
        duplicates = frame.loc[frame["sample_id"].duplicated(), "sample_id"].tolist()
        raise ValueError(f"Duplicate sample_id values: {duplicates[:10]}")
    if frame["participant_id"].isna().any():
        raise ValueError("participant_id contains missing values")
    labels = set(pd.to_numeric(frame["label"], errors="raise").astype(int).unique())
    if not labels <= {0, 1}:
        raise ValueError(f"Expected binary labels 0/1, found {sorted(labels)}")
    per_participant = frame.groupby("participant_id")["label"].nunique()
    if (per_participant > 1).any():
        bad = per_participant[per_participant > 1].index.tolist()
        raise ValueError(f"Participants with inconsistent labels: {bad[:10]}")


def make_grouped_folds(
    manifest: pd.DataFrame,
    num_folds: int = 10,
    seed: int = 2026,
) -> pd.DataFrame:
    """Assign one outer fold per participant using stratified group CV."""
    validate_manifest(manifest)
    canonical = manifest.sort_values(["participant_id", "sample_id"]).reset_index(drop=True)
    y = canonical["label"].astype(int).to_numpy()
    groups = canonical["participant_id"].astype(str).to_numpy()
    splitter = StratifiedGroupKFold(n_splits=num_folds, shuffle=True, random_state=seed)
    assignments = np.zeros(len(canonical), dtype=np.int64)
    dummy_x = np.zeros((len(canonical), 1), dtype=np.float32)
    for fold_index, (_, test_index) in enumerate(splitter.split(dummy_x, y, groups), start=1):
        assignments[test_index] = fold_index
    if np.any(assignments == 0):
        raise RuntimeError("At least one sample was not assigned to a fold")
    result = canonical[["sample_id", "participant_id", "label"]].copy()
    result["fold"] = assignments
    assert_participant_disjoint(result)
    return result.sort_values(["fold", "participant_id", "sample_id"]).reset_index(drop=True)


def assert_participant_disjoint(assignments: pd.DataFrame) -> None:
    required = {"sample_id", "participant_id", "label", "fold"}
    missing = required - set(assignments.columns)
    if missing:
        raise ValueError(f"Fold assignment file is missing: {sorted(missing)}")
    folds_per_participant = assignments.groupby("participant_id")["fold"].nunique()
    if (folds_per_participant != 1).any():
        bad = folds_per_participant[folds_per_participant != 1].index.tolist()
        raise ValueError(f"Participant leakage detected for: {bad[:10]}")
    if assignments["sample_id"].duplicated().any():
        raise ValueError("Duplicate sample_id in fold assignment file")


def fold_composition(assignments: pd.DataFrame) -> pd.DataFrame:
    assert_participant_disjoint(assignments)
    rows = []
    for fold, group in assignments.groupby("fold", sort=True):
        labels = group["label"].astype(int)
        rows.append(
            {
                "fold": int(fold),
                "participants": int(group["participant_id"].nunique()),
                "samples": int(len(group)),
                "depressed": int((labels == 1).sum()),
                "non_depressed": int((labels == 0).sum()),
            }
        )
    return pd.DataFrame(rows)


def outer_split_folds(test_fold: int, num_folds: int = 10) -> tuple[list[int], int, int]:
    if not 1 <= test_fold <= num_folds:
        raise ValueError(f"test_fold must be in [1, {num_folds}]")
    validation_fold = test_fold % num_folds + 1
    training_folds = [
        fold for fold in range(1, num_folds + 1) if fold not in {test_fold, validation_fold}
    ]
    return training_folds, validation_fold, test_fold


def load_and_join_manifest(
    manifest_path: str | Path,
    assignments_path: str | Path,
) -> pd.DataFrame:
    manifest = pd.read_csv(manifest_path, dtype={"sample_id": str, "participant_id": str})
    validate_manifest(manifest)
    assignments = pd.read_csv(
        assignments_path, dtype={"sample_id": str, "participant_id": str}
    )
    assert_participant_disjoint(assignments)
    joined = manifest.merge(
        assignments[["sample_id", "fold"]], on="sample_id", how="left", validate="one_to_one"
    )
    if joined["fold"].isna().any():
        missing = joined.loc[joined["fold"].isna(), "sample_id"].tolist()
        raise ValueError(f"Samples missing fold assignments: {missing[:10]}")
    joined["fold"] = joined["fold"].astype(int)
    return joined
