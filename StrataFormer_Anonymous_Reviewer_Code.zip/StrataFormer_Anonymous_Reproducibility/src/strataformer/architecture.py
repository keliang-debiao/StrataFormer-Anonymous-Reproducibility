from __future__ import annotations

from typing import Any


def sequence_contract(config: dict[str, Any]) -> dict[str, int | float]:
    data = config["data"]
    model = config["model"]
    audio_local = int(data["audio_target_length"])
    visual_local = int(data["visual_target_length"])
    for _ in range(int(model["visual_pool_blocks"])):
        visual_local //= 2
    audio_global = audio_local // int(model["global_audio_pool"])
    visual_global = visual_local // int(model["global_visual_pool"])
    local_pairs = (visual_local + 1) * audio_local
    global_pairs = (visual_global + 1) * audio_global
    return {
        "audio_local_positions": audio_local,
        "visual_local_chronological_positions": visual_local,
        "visual_local_queries_with_cls": visual_local + 1,
        "audio_global_positions": audio_global,
        "visual_global_chronological_positions": visual_global,
        "visual_global_queries_with_cls": visual_global + 1,
        "local_attention_pairs": local_pairs,
        "global_attention_pairs": global_pairs,
        "full_attention_pairs": local_pairs + global_pairs,
        "global_pairs_as_percent_of_local": 100.0 * global_pairs / local_pairs,
        "full_increase_over_local_percent": 100.0 * global_pairs / local_pairs,
    }


def analytical_parameter_counts(config: dict[str, Any]) -> dict[str, int]:
    """Count parameters for the architecture in this repository without importing torch."""
    data = config["data"]
    model = config["model"]
    audio_dim = int(data["audio_dim"])
    visual_dim = int(data["visual_dim"])
    d_model = int(model["d_model"])
    channels = int(model["visual_hidden_channels"])
    kernel = int(model["temporal_kernel_size"])
    pool_blocks = int(model["visual_pool_blocks"])
    residual_blocks = len(model["visual_residual_dilations"])
    hidden = int(model["classifier_hidden"])
    classes = int(model["num_classes"])

    linear_audio = audio_dim * d_model + d_model
    first_pool_block = channels * visual_dim * kernel + channels + 2 * channels
    later_pool_block = channels * channels * kernel + channels + 2 * channels
    residual_tcn = residual_blocks * 2 * (channels * channels * kernel + channels)
    visual_output = channels * d_model + d_model
    encoder = linear_audio + first_pool_block + (pool_blocks - 1) * later_pool_block + residual_tcn + visual_output
    one_attention = 4 * d_model * d_model + 6 * d_model

    def classifier(input_width: int) -> int:
        return input_width * hidden + hidden + hidden * classes + classes

    return {
        "global": encoder + one_attention + d_model + classifier(d_model),
        "local": encoder + one_attention + d_model + classifier(d_model),
        "serial": encoder + 2 * one_attention + 2 * d_model + classifier(d_model),
        "full": encoder + 2 * one_attention + 2 * d_model + classifier(2 * d_model),
    }
