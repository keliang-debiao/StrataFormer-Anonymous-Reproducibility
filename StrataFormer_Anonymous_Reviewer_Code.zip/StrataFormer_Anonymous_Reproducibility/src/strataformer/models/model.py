from __future__ import annotations

from typing import Any

import torch
from torch import Tensor, nn

from .fusion import CrossModalAttention, prepend_cls
from .masking import apply_mask, masked_average_pool
from .tcn import VisualTemporalEncoder


class StrataFormer(nn.Module):
    """Parallel local/global masked cross-attention model described in the paper."""

    VALID_VARIANTS = {"full", "local", "global", "serial"}

    def __init__(self, data_config: dict[str, Any], model_config: dict[str, Any]) -> None:
        super().__init__()
        self.variant = str(model_config["variant"])
        if self.variant not in self.VALID_VARIANTS:
            raise ValueError(f"Unknown variant {self.variant!r}; expected {sorted(self.VALID_VARIANTS)}")

        d_model = int(model_config["d_model"])
        self.global_audio_pool = int(model_config["global_audio_pool"])
        self.global_visual_pool = int(model_config["global_visual_pool"])
        self.audio_projection = nn.Linear(int(data_config["audio_dim"]), d_model)
        self.visual_encoder = VisualTemporalEncoder(
            input_dim=int(data_config["visual_dim"]),
            hidden_channels=int(model_config["visual_hidden_channels"]),
            output_dim=d_model,
            residual_dilations=list(model_config["visual_residual_dilations"]),
            kernel_size=int(model_config["temporal_kernel_size"]),
            dropout=float(model_config["tcn_dropout"]),
            pool_blocks=int(model_config["visual_pool_blocks"]),
        )
        attention_args = (
            d_model,
            int(model_config["num_heads"]),
            float(model_config["attention_dropout"]),
        )
        self.local_attention = (
            CrossModalAttention(*attention_args)
            if self.variant in {"full", "local", "serial"}
            else None
        )
        self.global_attention = (
            CrossModalAttention(*attention_args) if self.variant in {"full", "global"} else None
        )
        self.serial_global_attention = (
            CrossModalAttention(*attention_args) if self.variant == "serial" else None
        )
        self.local_cls = (
            nn.Parameter(torch.zeros(1, 1, d_model))
            if self.variant in {"full", "local", "serial"}
            else None
        )
        self.global_cls = (
            nn.Parameter(torch.zeros(1, 1, d_model))
            if self.variant in {"full", "global", "serial"}
            else None
        )
        if self.local_cls is not None:
            nn.init.trunc_normal_(self.local_cls, std=0.02)
        if self.global_cls is not None:
            nn.init.trunc_normal_(self.global_cls, std=0.02)

        classifier_input = d_model * 2 if self.variant == "full" else d_model
        self.classifier = nn.Sequential(
            nn.Linear(classifier_input, int(model_config["classifier_hidden"])),
            nn.ReLU(inplace=True),
            nn.Dropout(float(model_config["classifier_dropout"])),
            nn.Linear(int(model_config["classifier_hidden"]), int(model_config["num_classes"])),
        )

    def _local(
        self,
        visual: Tensor,
        visual_mask: Tensor,
        audio: Tensor,
        audio_mask: Tensor,
        return_attention: bool,
    ) -> tuple[Tensor, Tensor, Tensor, Tensor | None]:
        if self.local_attention is None or self.local_cls is None:
            raise RuntimeError("Local attention is unavailable for this variant")
        visual_with_cls, query_mask = prepend_cls(visual, visual_mask, self.local_cls)
        output, weights = self.local_attention(
            visual_with_cls,
            audio,
            query_mask,
            audio_mask,
            return_attention,
        )
        return output[:, 0], output[:, 1:], visual_mask, weights

    def _global(
        self,
        visual: Tensor,
        visual_mask: Tensor,
        audio: Tensor,
        audio_mask: Tensor,
        return_attention: bool,
    ) -> tuple[Tensor, Tensor | None]:
        if self.global_attention is None or self.global_cls is None:
            raise RuntimeError("Global attention is unavailable for this variant")
        pooled_visual, pooled_visual_mask = masked_average_pool(
            visual, visual_mask, self.global_visual_pool
        )
        pooled_audio, pooled_audio_mask = masked_average_pool(
            audio, audio_mask, self.global_audio_pool
        )
        visual_with_cls, query_mask = prepend_cls(
            pooled_visual, pooled_visual_mask, self.global_cls
        )
        output, weights = self.global_attention(
            visual_with_cls,
            pooled_audio,
            query_mask,
            pooled_audio_mask,
            return_attention,
        )
        return output[:, 0], weights

    def forward(
        self,
        audio: Tensor,
        visual: Tensor,
        audio_mask: Tensor,
        visual_mask: Tensor,
        return_attention: bool = False,
    ) -> dict[str, Tensor | dict[str, Tensor | None]]:
        if (~audio_mask).all(dim=1).any() or (~visual_mask).all(dim=1).any():
            raise ValueError("Each modality must have at least one valid timestep per sample")
        audio = apply_mask(self.audio_projection(audio), audio_mask)
        visual, visual_mask = self.visual_encoder(visual, visual_mask)
        attention_maps: dict[str, Tensor | None] = {}

        if self.variant == "local":
            representation, _, _, attention_maps["local"] = self._local(
                visual, visual_mask, audio, audio_mask, return_attention
            )
        elif self.variant == "global":
            representation, attention_maps["global"] = self._global(
                visual, visual_mask, audio, audio_mask, return_attention
            )
        elif self.variant == "serial":
            if self.serial_global_attention is None:
                raise RuntimeError("Serial global attention is unavailable for this variant")
            _, local_sequence, local_mask, attention_maps["local"] = self._local(
                visual, visual_mask, audio, audio_mask, return_attention
            )
            pooled_visual, pooled_visual_mask = masked_average_pool(
                local_sequence, local_mask, self.global_visual_pool
            )
            pooled_audio, pooled_audio_mask = masked_average_pool(
                audio, audio_mask, self.global_audio_pool
            )
            visual_with_cls, query_mask = prepend_cls(
                pooled_visual, pooled_visual_mask, self.global_cls
            )
            serial_output, attention_maps["global"] = self.serial_global_attention(
                visual_with_cls,
                pooled_audio,
                query_mask,
                pooled_audio_mask,
                return_attention,
            )
            representation = serial_output[:, 0]
        else:
            local_cls, _, _, attention_maps["local"] = self._local(
                visual, visual_mask, audio, audio_mask, return_attention
            )
            global_cls, attention_maps["global"] = self._global(
                visual, visual_mask, audio, audio_mask, return_attention
            )
            representation = torch.cat([local_cls, global_cls], dim=-1)

        result: dict[str, Tensor | dict[str, Tensor | None]] = {
            "logits": self.classifier(representation),
            "representation": representation,
        }
        if return_attention:
            result["attention"] = attention_maps
        return result


def build_model(config: dict[str, Any], variant: str | None = None) -> StrataFormer:
    model_config = dict(config["model"])
    if variant is not None:
        model_config["variant"] = variant
    return StrataFormer(config["data"], model_config)
