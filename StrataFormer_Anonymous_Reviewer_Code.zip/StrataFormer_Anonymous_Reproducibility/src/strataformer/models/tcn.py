from __future__ import annotations

import torch
from torch import Tensor, nn

from .masking import apply_mask, pool_mask


class MaskedConvPoolBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int = 3) -> None:
        super().__init__()
        padding = kernel_size // 2
        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size, padding=padding)
        self.norm = nn.BatchNorm1d(out_channels)
        self.activation = nn.ReLU(inplace=True)
        self.pool = nn.MaxPool1d(kernel_size=2, stride=2, ceil_mode=False)

    def forward(self, sequence: Tensor, mask: Tensor) -> tuple[Tensor, Tensor]:
        sequence = apply_mask(sequence, mask)
        sequence = self.activation(self.norm(self.conv(sequence.transpose(1, 2))))
        sequence = self.pool(sequence).transpose(1, 2)
        mask = pool_mask(mask, kernel_size=2, stride=2)
        return apply_mask(sequence, mask), mask


class MaskedResidualTCNBlock(nn.Module):
    def __init__(
        self,
        channels: int,
        dilation: int,
        kernel_size: int = 3,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        padding = dilation * (kernel_size - 1) // 2
        self.conv1 = nn.Conv1d(
            channels,
            channels,
            kernel_size=kernel_size,
            dilation=dilation,
            padding=padding,
        )
        self.conv2 = nn.Conv1d(
            channels,
            channels,
            kernel_size=kernel_size,
            dilation=dilation,
            padding=padding,
        )
        self.activation = nn.ReLU(inplace=True)
        self.dropout = nn.Dropout(dropout)

    def forward(self, sequence: Tensor, mask: Tensor) -> Tensor:
        residual = apply_mask(sequence, mask)
        hidden = self.conv1(residual.transpose(1, 2))
        hidden = self.dropout(self.activation(hidden))
        hidden = self.conv2(hidden)
        hidden = self.dropout(self.activation(hidden)).transpose(1, 2)
        return apply_mask(residual + hidden, mask)


class VisualTemporalEncoder(nn.Module):
    """Three masked Conv-BN-ReLU-MaxPool blocks and four residual TCN blocks."""

    def __init__(
        self,
        input_dim: int,
        hidden_channels: int,
        output_dim: int,
        residual_dilations: list[int],
        kernel_size: int = 3,
        dropout: float = 0.1,
        pool_blocks: int = 3,
    ) -> None:
        super().__init__()
        blocks = []
        in_channels = input_dim
        for _ in range(pool_blocks):
            blocks.append(MaskedConvPoolBlock(in_channels, hidden_channels, kernel_size))
            in_channels = hidden_channels
        self.pool_blocks = nn.ModuleList(blocks)
        self.residual_blocks = nn.ModuleList(
            [
                MaskedResidualTCNBlock(hidden_channels, dilation, kernel_size, dropout)
                for dilation in residual_dilations
            ]
        )
        self.output_projection = nn.Linear(hidden_channels, output_dim)

    def forward(self, visual: Tensor, mask: Tensor) -> tuple[Tensor, Tensor]:
        hidden = visual
        for block in self.pool_blocks:
            hidden, mask = block(hidden, mask)
        for block in self.residual_blocks:
            hidden = block(hidden, mask)
        hidden = self.output_projection(hidden)
        return apply_mask(hidden, mask), mask
