from __future__ import annotations

import torch
from torch import Tensor, nn

from .masking import apply_mask


class CrossModalAttention(nn.Module):
    """Visual-query/audio-key-value cross-attention with validity masks."""

    def __init__(self, d_model: int, num_heads: int, dropout: float) -> None:
        super().__init__()
        self.attention = nn.MultiheadAttention(
            embed_dim=d_model,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True,
        )
        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(d_model)

    def forward(
        self,
        visual_queries: Tensor,
        audio_keys_values: Tensor,
        visual_mask: Tensor,
        audio_mask: Tensor,
        return_attention: bool = False,
    ) -> tuple[Tensor, Tensor | None]:
        if (~audio_mask).all(dim=1).any():
            raise ValueError("Every sample must contain at least one valid audio position")
        queries = apply_mask(visual_queries, visual_mask)
        keys_values = apply_mask(audio_keys_values, audio_mask)
        attended, weights = self.attention(
            query=queries,
            key=keys_values,
            value=keys_values,
            key_padding_mask=~audio_mask,
            need_weights=return_attention,
            average_attn_weights=False,
        )
        output = self.norm(queries + self.dropout(attended))
        output = apply_mask(output, visual_mask)
        return output, weights if return_attention else None


def prepend_cls(sequence: Tensor, mask: Tensor, cls_token: Tensor) -> tuple[Tensor, Tensor]:
    batch_size = sequence.shape[0]
    token = cls_token.expand(batch_size, -1, -1)
    sequence = torch.cat([token, sequence], dim=1)
    cls_mask = torch.ones((batch_size, 1), dtype=torch.bool, device=mask.device)
    return sequence, torch.cat([cls_mask, mask], dim=1)
