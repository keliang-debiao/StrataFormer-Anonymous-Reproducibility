from __future__ import annotations

import torch
from torch import Tensor
from torch.nn import functional as F


def apply_mask(sequence: Tensor, mask: Tensor) -> Tensor:
    """Set invalid [B, T] positions in a [B, T, D] tensor to zero."""
    if sequence.ndim != 3 or mask.ndim != 2:
        raise ValueError("Expected sequence [B, T, D] and mask [B, T]")
    if sequence.shape[:2] != mask.shape:
        raise ValueError(f"Mask shape {mask.shape} does not match {sequence.shape[:2]}")
    return sequence * mask.to(dtype=sequence.dtype).unsqueeze(-1)


def pool_mask(mask: Tensor, kernel_size: int, stride: int | None = None) -> Tensor:
    """A pooled position is valid when at least one source position is valid."""
    stride = kernel_size if stride is None else stride
    pooled = F.max_pool1d(
        mask.to(dtype=torch.float32).unsqueeze(1),
        kernel_size=kernel_size,
        stride=stride,
        ceil_mode=False,
    )
    return pooled.squeeze(1).to(dtype=torch.bool)


def masked_average_pool(
    sequence: Tensor,
    mask: Tensor,
    kernel_size: int,
    stride: int | None = None,
) -> tuple[Tensor, Tensor]:
    """Floor-mode average pooling that excludes zero-padded positions."""
    stride = kernel_size if stride is None else stride
    masked = apply_mask(sequence, mask)
    numerator = F.avg_pool1d(
        masked.transpose(1, 2),
        kernel_size=kernel_size,
        stride=stride,
        ceil_mode=False,
    ) * kernel_size
    denominator = F.avg_pool1d(
        mask.to(dtype=sequence.dtype).unsqueeze(1),
        kernel_size=kernel_size,
        stride=stride,
        ceil_mode=False,
    ) * kernel_size
    pooled_mask = denominator.squeeze(1) > 0
    pooled = numerator / denominator.clamp_min(1.0)
    pooled = apply_mask(pooled.transpose(1, 2), pooled_mask)
    return pooled, pooled_mask
