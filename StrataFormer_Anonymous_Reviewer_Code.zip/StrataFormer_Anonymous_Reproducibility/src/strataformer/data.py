from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


def _load_feature(path: Path, expected_dim: int) -> np.ndarray:
    array = np.load(path, allow_pickle=False)
    if array.ndim != 2 or array.shape[1] != expected_dim:
        raise ValueError(f"Expected [T, {expected_dim}] at {path}, found {array.shape}")
    return np.asarray(array, dtype=np.float32)


def _common_interval_crop(
    audio: np.ndarray,
    visual: np.ndarray,
    audio_step_seconds: float | None,
    visual_step_seconds: float | None,
) -> tuple[np.ndarray, np.ndarray]:
    if audio_step_seconds is None or visual_step_seconds is None:
        return audio, visual
    audio_duration = len(audio) * audio_step_seconds
    visual_duration = len(visual) * visual_step_seconds
    common_duration = min(audio_duration, visual_duration)
    audio_steps = min(len(audio), int(np.floor(common_duration / audio_step_seconds + 1e-9)))
    visual_steps = min(len(visual), int(np.floor(common_duration / visual_step_seconds + 1e-9)))
    return audio[:audio_steps], visual[:visual_steps]


def standardize_length(array: np.ndarray, target: int) -> tuple[np.ndarray, np.ndarray]:
    valid_length = min(len(array), target)
    result = np.zeros((target, array.shape[1]), dtype=np.float32)
    result[:valid_length] = array[:valid_length]
    mask = np.zeros(target, dtype=np.bool_)
    mask[:valid_length] = True
    return result, mask


@dataclass
class ModalityStats:
    audio_mean: np.ndarray
    audio_std: np.ndarray
    visual_mean: np.ndarray
    visual_std: np.ndarray

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            path,
            audio_mean=self.audio_mean,
            audio_std=self.audio_std,
            visual_mean=self.visual_mean,
            visual_std=self.visual_std,
        )

    @classmethod
    def load(cls, path: str | Path) -> "ModalityStats":
        payload = np.load(path, allow_pickle=False)
        return cls(
            audio_mean=payload["audio_mean"],
            audio_std=payload["audio_std"],
            visual_mean=payload["visual_mean"],
            visual_std=payload["visual_std"],
        )


def _streaming_stats(arrays: Iterable[np.ndarray], dimension: int, eps: float) -> tuple[np.ndarray, np.ndarray]:
    count = 0
    total = np.zeros(dimension, dtype=np.float64)
    squared = np.zeros(dimension, dtype=np.float64)
    for array in arrays:
        finite = np.where(np.isfinite(array), array, 0.0).astype(np.float64, copy=False)
        count += len(finite)
        total += finite.sum(axis=0)
        squared += np.square(finite).sum(axis=0)
    if count == 0:
        raise ValueError("Cannot estimate normalization statistics from zero valid positions")
    mean = total / count
    variance = np.maximum(squared / count - np.square(mean), 0.0)
    std = np.maximum(np.sqrt(variance), eps)
    return mean.astype(np.float32), std.astype(np.float32)


def fit_modality_stats(
    frame: pd.DataFrame,
    data_root: str | Path,
    audio_dim: int = 128,
    visual_dim: int = 171,
    audio_target: int = 186,
    visual_target: int = 915,
    eps: float = 1e-6,
    restrict_to_common_interval: bool = True,
    features_already_common_interval: bool = False,
) -> ModalityStats:
    root = Path(data_root)

    audio_arrays: list[np.ndarray] = []
    visual_arrays: list[np.ndarray] = []
    for _, row in frame.iterrows():
        audio = _load_feature(root / str(row.audio_path), audio_dim)
        visual = _load_feature(root / str(row.visual_path), visual_dim)
        if restrict_to_common_interval and not features_already_common_interval:
            audio_step = None if pd.isna(row.get("audio_step_seconds", np.nan)) else float(row["audio_step_seconds"])
            visual_step = None if pd.isna(row.get("visual_step_seconds", np.nan)) else float(row["visual_step_seconds"])
            audio, visual = _common_interval_crop(audio, visual, audio_step, visual_step)
        audio_arrays.append(audio[:audio_target])
        visual_arrays.append(visual[:visual_target])

    audio_mean, audio_std = _streaming_stats(audio_arrays, audio_dim, eps)
    visual_mean, visual_std = _streaming_stats(visual_arrays, visual_dim, eps)
    return ModalityStats(audio_mean, audio_std, visual_mean, visual_std)


class LMVDDataset:
    """PyTorch-compatible dataset loaded lazily to avoid importing torch for audits."""

    def __init__(
        self,
        frame: pd.DataFrame,
        data_root: str | Path,
        stats: ModalityStats,
        audio_dim: int = 128,
        visual_dim: int = 171,
        audio_target: int = 186,
        visual_target: int = 915,
        restrict_to_common_interval: bool = True,
        features_already_common_interval: bool = False,
    ) -> None:
        self.frame = frame.reset_index(drop=True).copy()
        self.root = Path(data_root)
        self.stats = stats
        self.audio_dim = audio_dim
        self.visual_dim = visual_dim
        self.audio_target = audio_target
        self.visual_target = visual_target
        self.restrict_to_common_interval = restrict_to_common_interval
        self.features_already_common_interval = features_already_common_interval

    def __len__(self) -> int:
        return len(self.frame)

    @staticmethod
    def _optional_float(row: pd.Series, key: str) -> float | None:
        value = row.get(key, np.nan)
        return None if pd.isna(value) else float(value)

    def __getitem__(self, index: int):
        import torch

        row = self.frame.iloc[index]
        audio = _load_feature(self.root / str(row.audio_path), self.audio_dim)
        visual = _load_feature(self.root / str(row.visual_path), self.visual_dim)
        if self.restrict_to_common_interval and not self.features_already_common_interval:
            audio, visual = _common_interval_crop(
                audio,
                visual,
                self._optional_float(row, "audio_step_seconds"),
                self._optional_float(row, "visual_step_seconds"),
            )
        audio = np.where(np.isfinite(audio), audio, 0.0)
        visual = np.where(np.isfinite(visual), visual, 0.0)
        audio, audio_mask = standardize_length(audio, self.audio_target)
        visual, visual_mask = standardize_length(visual, self.visual_target)
        audio = (audio - self.stats.audio_mean) / self.stats.audio_std
        visual = (visual - self.stats.visual_mean) / self.stats.visual_std
        audio[~audio_mask] = 0.0
        visual[~visual_mask] = 0.0
        return {
            "sample_id": str(row.sample_id),
            "participant_id": str(row.participant_id),
            "audio": torch.from_numpy(audio),
            "audio_mask": torch.from_numpy(audio_mask),
            "visual": torch.from_numpy(visual),
            "visual_mask": torch.from_numpy(visual_mask),
            "label": torch.tensor(int(row.label), dtype=torch.long),
        }
