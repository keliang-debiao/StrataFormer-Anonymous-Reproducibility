from __future__ import annotations

import numpy as np
from scipy import stats


def paired_fold_analysis(full: np.ndarray, comparator: np.ndarray) -> dict[str, float | int]:
    full = np.asarray(full, dtype=np.float64)
    comparator = np.asarray(comparator, dtype=np.float64)
    if full.shape != comparator.shape or full.ndim != 1 or len(full) < 3:
        raise ValueError("Expected two one-dimensional matched arrays of length >= 3")
    difference = full - comparator
    shapiro = stats.shapiro(difference)
    paired = stats.ttest_rel(full, comparator)
    n = len(difference)
    mean_difference = float(difference.mean())
    sample_sd = float(difference.std(ddof=1))
    standard_error = sample_sd / np.sqrt(n)
    critical = float(stats.t.ppf(0.975, df=n - 1))
    return {
        "n_folds": n,
        "mean_difference": mean_difference,
        "difference_sample_sd": sample_sd,
        "shapiro_w": float(shapiro.statistic),
        "shapiro_p": float(shapiro.pvalue),
        "paired_t": float(paired.statistic),
        "degrees_of_freedom": n - 1,
        "paired_p": float(paired.pvalue),
        "ci95_low": mean_difference - critical * standard_error,
        "ci95_high": mean_difference + critical * standard_error,
        "cohens_dz": mean_difference / sample_sd if sample_sd > 0 else 0.0,
    }
