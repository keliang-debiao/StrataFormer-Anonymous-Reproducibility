# Reference logs

Every file in this directory carries the notice `REFERENCE LOG — NOT A RAW TRAINING TRANSCRIPT`.

- The `*_reference.log` files are deterministic textual views of manuscript tables.
- `reference_training_format.jsonl` is a reference-format software-workflow example for parser and AI-agent testing.
- None of these files proves that training was rerun.

Regenerate them with `python scripts/generate_reference_logs.py`. Place genuine rerun logs under `outputs/`; do not overwrite or relabel these fixtures.
